export const baseURL = process.env.NODE_ENV === 'production'
  ? '/api/'
  : ''
