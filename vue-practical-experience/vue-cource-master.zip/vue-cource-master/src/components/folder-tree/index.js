import FolderTree from './folder-tree.vue'
export default FolderTree
