import FormSingle from './form-single.vue'
export default FormSingle
