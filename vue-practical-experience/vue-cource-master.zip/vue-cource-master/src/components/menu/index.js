import AMenu from './a-menu.vue'
import AMenuItem from './a-menu-item.vue'
import ASubmenu from './a-submenu.vue'
export default {
  AMenu,
  AMenuItem,
  ASubmenu
}
