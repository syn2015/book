import EditTable from './edit-table.vue'
export default EditTable
