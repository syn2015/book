import EditTableMul from './edit-table-mul.vue'
export default EditTableMul
