import SplitPane from './split-pane.vue'
export default SplitPane
