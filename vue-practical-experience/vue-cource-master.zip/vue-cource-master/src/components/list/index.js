import List from './list.vue'
export default List
