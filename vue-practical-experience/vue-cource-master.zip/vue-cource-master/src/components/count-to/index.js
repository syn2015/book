import CountTo from './count-to.vue'
export default CountTo
