import IconFont from './icon-font.vue'
export default IconFont
