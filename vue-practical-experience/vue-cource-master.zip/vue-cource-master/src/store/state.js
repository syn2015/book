const state = {
  appName: 'admin',
  stateValue: 'abc'
}
export default state
