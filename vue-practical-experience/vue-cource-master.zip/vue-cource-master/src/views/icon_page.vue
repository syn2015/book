<template>
  <div>
    <Icon type="md-menu" :size="50" color="pink"/>
    <i class="iconfont smile">&#xe619;</i>
    <i class="iconfont">&#xe618;</i>
    <svg class="iconfont-svg" aria-hidden="true" style="font-size: 70px;">
      <use xlink:href="#icon-zhaoxiangji-"></use>
    </svg>
    <!-- <i class="iconfont icon-shouye4"></i> -->
    <Icon custom="iconfont icon-shouye4"/>
    <icon-font icon="shouye3" :size="50" color="blue"></icon-font>
    <icon-svg icon="zhuye-" :size="100"></icon-svg>
  </div>
</template>

<script>
export default {
  //
}
</script>

<style>
.smile{
  color: red;
}
</style>
