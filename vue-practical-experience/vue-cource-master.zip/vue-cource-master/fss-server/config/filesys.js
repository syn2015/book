const path = require('path')
module.exports = {
	path: path.join(__dirname, '../../', 'file_storage')
}
